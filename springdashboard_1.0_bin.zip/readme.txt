JComet is a part of the Spacebug open source initiative

Example of use:
See war in example folder and run it on a servlet container (e.g tomcat)

For more information and support:
Please visit http://spacebug.com/projects_spring-dashboard.html
